package com.cts.project.HaircutSpaBookingSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HaircutSpaBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
