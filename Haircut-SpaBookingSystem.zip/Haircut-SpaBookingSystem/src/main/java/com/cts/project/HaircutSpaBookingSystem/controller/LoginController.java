package com.cts.project.HaircutSpaBookingSystem.controller;

import javax.servlet.http.HttpSession;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cts.project.HaircutSpaBookingSystem.dao.User;
import com.cts.project.HaircutSpaBookingSystem.service.AdminService;
import com.cts.project.HaircutSpaBookingSystem.service.UserService;

@Controller
@SessionAttributes({ "email", "userName" })
public class LoginController {

	@Autowired
	AdminService AdminService;
	
	@Autowired
	UserService UserService;

	@Autowired
	User user;

	@RequestMapping(value = "/services", method = RequestMethod.GET)
	public String showServicesPage(ModelMap model, HttpSession session) {
		String email = (String) session.getAttribute("email");
		if (email == null) {
			return "index";
		} else {
			return "services";
		}

	}

	@RequestMapping(value = "/aboutus", method = RequestMethod.GET)
	public String showAboutusPage(ModelMap model) {
		return "aboutus";
	}

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String showIndexPage(ModelMap model) {
		return "index";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String handleLogin(ModelMap model, @RequestParam String email, @RequestParam String password,
			@RequestParam String userType, HttpSession session) {

		if(userType.equals("admin")){
			boolean isValidAdmin = AdminService.validateUser( email,password);
			
			if(isValidAdmin) {
				//System.out.println(AdminService.getAllBooking());
				model.put("listall", AdminService.getAllBooking());
				return "admin";	
			}
			else {
				return "redirect:/index";
			}
		} else {
			boolean isValidUser = UserService.isValidUser(email, password);
			if (isValidUser) {
				model.put("email", email);
				session.setAttribute("email", email);
				session.setAttribute("LoginMsg", "Yes");
				return "redirect:/services";
			}

			else {
				//model.put("errorMessage", "Invalid Credentials!!");	
				session.setAttribute("LoginMsg", "No");
				return "redirect:/index";
			}
		}
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutUser(ModelMap model, HttpSession session) {
		model.remove("email");
		// session=request.getSession();
		session.setAttribute("email", null);
		session.invalidate();
		return "redirect:/index";
	}

}
