package com.cts.project.HaircutSpaBookingSystem.controller;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.TimeZone;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cts.project.HaircutSpaBookingSystem.dao.User;
import com.cts.project.HaircutSpaBookingSystem.dao.bookings;
import com.cts.project.HaircutSpaBookingSystem.service.BookingService;
import com.cts.project.HaircutSpaBookingSystem.service.UserService;

@Controller
@SessionAttributes({"email", "userName"})
public class BookingsController  {
			
	@Autowired
	UserService UserService ;
	
	@Autowired
	BookingService bookingservice;
	
	@Autowired
	bookings bookings;
	
	@Autowired
	User user;
	
	@RequestMapping(value = "/bookservice", method = RequestMethod.GET) 
	public String openPage(ModelMap model) { 
		
		return "bookservice";
	}
	
	@RequestMapping(value = "/mybookings", method = RequestMethod.GET) 
	public String showMybookingsPage(ModelMap model, HttpSession session) { 
		String email = (String)session.getAttribute("email");
		if(email == null) {
			return "index";
		}else {
			
			model.addAttribute("listBookings", bookingservice.getUserBooking(email));
			return "mybookings";
		}
		
	}
	
	// code for book an appointment 
	@RequestMapping(value = "/BookTask", method = RequestMethod.POST) 
	public String bookappointment(ModelMap model, @RequestParam String services, @RequestParam String date,
			@RequestParam String timeslot, HttpSession session) { 
		//System.out.println(services+ date+ timeslot);
		
		String email = (String)session.getAttribute("email");
		SimpleDateFormat sd = new SimpleDateFormat("yyyy.MM.dd G 'at' HH:mm:ss z");
	    Date bdate = new Date();
	    sd.setTimeZone(TimeZone.getTimeZone("IST"));
	    String booktime = sd.format(bdate).toString();
		String bookingid = email + booktime;
		
		bookingservice.addbooking(new bookings(bookingid, email, services, date, timeslot, booktime));
		session.setAttribute("AlertBook", "Yes");
		
		return "redirect:/mybookings";
	}
	
	
	@RequestMapping(value = "/bookedslots", method = RequestMethod.GET) 
	@ResponseBody
	public String bookedslots(@RequestParam String inpdate, ModelMap model) { 
		
		String result = bookingservice.getbookedslots(inpdate);
		return result;
	}
}
