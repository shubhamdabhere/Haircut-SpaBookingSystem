package com.cts.project.HaircutSpaBookingSystem.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cts.project.HaircutSpaBookingSystem.dao.bookings;


@Service
public class AdminService {
	
	@Autowired
	BookingService BookingService;
	
	@Autowired
	JdbcTemplate jdbc;

	  public boolean validateUser(String email, String password) {
	        return email.equalsIgnoreCase("shubhamdabhere08@gmail.com") && password.equals("1234");
	    }
	  
	  public List<bookings> getAllBooking() {
			List<bookings> allBookings = new ArrayList<bookings>();

			SqlRowSet queryForRowSet = jdbc.queryForRowSet("select * from bookings");
			while (queryForRowSet.next()) {
				// Get time corresponding to integer time slot
				String time= BookingService.getBookingSlot(queryForRowSet.getInt("timeslot"));
				
				allBookings.add(new bookings(queryForRowSet.getString("bookingid"),queryForRowSet.getString("email"),
						queryForRowSet.getString("service"), queryForRowSet.getString("date"),
						time, queryForRowSet.getString("booktime")));
			}
			
			Collections.sort(allBookings, new Comparator<bookings>() {
				public int compare(bookings o1, bookings o2) {
					if (o1.getDate() == null || o2.getDate() == null)
						return 0;
					return o1.getDate().compareTo(o2.getDate());
				}
			});
			
			//System.out.println(allBookings);
			return allBookings;

		}
		

}