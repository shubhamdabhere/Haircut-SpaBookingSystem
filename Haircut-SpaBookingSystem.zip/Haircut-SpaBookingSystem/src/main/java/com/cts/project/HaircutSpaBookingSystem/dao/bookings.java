package com.cts.project.HaircutSpaBookingSystem.dao;

import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class bookings {
	
	private String bookingId;
	private String email;
	private String service;
	private String date;
	private String timeslot;
	private String booktime;
	
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTimeslot() {
		return timeslot;
	}
	public void setTimeslot(String timeslot) {
		this.timeslot = timeslot;
	}
	public String getBooktime() {
		return booktime;
	}
	public void setBooktime(String booktime) {
		this.booktime = booktime;
	}
	@Override
	public String toString() {
		return "bookings [bookingId=" + bookingId + ", email=" + email + ", service="
				+ service + ", date=" + date + ", timeslot=" + timeslot + ", booktime=" + booktime + "]";
	}
	public bookings() {
		super();
		// TODO Auto-generated constructor stub
	}
	public bookings(String bookingId, String email, String service, String date, String timeslot,
			String booktime) {
		super();
		this.bookingId = bookingId;
		this.email = email;
		this.service = service;
		this.date = date;
		this.timeslot = timeslot;
		this.booktime = booktime;
	}
	
	
	

}
