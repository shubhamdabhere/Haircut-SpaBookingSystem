package com.cts.project.HaircutSpaBookingSystem.controller;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cts.project.HaircutSpaBookingSystem.dao.User;
import com.cts.project.HaircutSpaBookingSystem.service.UserService;

@Controller
@SessionAttributes({"email", "userName"})
public class RegisterController {

	@Autowired
	UserService UserService;
	
	@Autowired
	User user;
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String handleRegister(ModelMap model, @RequestParam String userName, @RequestParam String email, @RequestParam String password,
			@RequestParam String repassword, @RequestParam String mobile) {
		
		//System.out.println("user " + user);
		UserService.addUser(new User(userName, email, password, mobile));
		return "redirect:/index";
		
	}
	
	@RequestMapping(value = "/repeatEmail", method = RequestMethod.GET) 
	@ResponseBody
	public boolean bookedslots(@RequestParam String emailCheck, ModelMap model) { 
		//System.out.println(emailCheck);
		boolean result = UserService.checkIfEmailExists(emailCheck);
		//System.out.println(result);
		return result; 
	}

}
