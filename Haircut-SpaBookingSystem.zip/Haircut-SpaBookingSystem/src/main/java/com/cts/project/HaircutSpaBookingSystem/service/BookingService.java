package com.cts.project.HaircutSpaBookingSystem.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Service;

import com.cts.project.HaircutSpaBookingSystem.dao.User;
import com.cts.project.HaircutSpaBookingSystem.dao.bookings;

@Service
public class BookingService {

	@Autowired
	User user;
	
	@Autowired
	bookings booking;
	
	@Autowired
	JdbcTemplate jdbc;
	
	public void addbooking(bookings booking) {
		String sql = "insert into bookings values(?,?,?,?,?,?)";
		//String date = booking.getDate().toString();
		try {
			int flag = jdbc.update(sql, booking.getBookingId(), booking.getEmail(), booking.getService(),
					booking.getDate(), booking.getTimeslot(), booking.getBooktime());
			//jdbc.update(sql, "apoorva", "abc@gmail.com", "123", "7772986606");
			
			//System.out.println(flag);
			
		} catch (Exception e) {
			System.out.println(e);
		}

	}
	
	public List<bookings> getUserBooking(String email) {
		List<bookings> userBookings = new ArrayList<bookings>();

		SqlRowSet queryForRowSet = jdbc.queryForRowSet("select * from bookings where email=?", email);
		while (queryForRowSet.next()) {
			String time= getBookingSlot(queryForRowSet.getInt("timeslot"));
			
			userBookings.add(new bookings(queryForRowSet.getString("bookingid"), email,
					queryForRowSet.getString("service"), queryForRowSet.getString("date"),
					time , queryForRowSet.getString("booktime")));
		}
		//System.out.println(email);
		//System.out.println(userBookings);
		
		Collections.sort(userBookings, new Comparator<bookings>() {
			public int compare(bookings o1, bookings o2) {
				if (o1.getDate() == null || o2.getDate() == null)
					return 0;
			    return o1.getDate().compareTo(o2.getDate());
			}
		});
		
		return userBookings;

	}
	

	public String getbookedslots(String inpdate) {
		String result="";
		try{
			
			SqlRowSet queryForRowSet = jdbc.queryForRowSet("select * from bookings where date=?", inpdate);
        
            int a[]=new int[23];
            
            for(int k=0;k<23;k++)
            {
                a[k]=0;
            }
            
            if(queryForRowSet.next()){
            	queryForRowSet.previous();
                while(queryForRowSet.next())
                {
                    a[Integer.parseInt(queryForRowSet.getString("timeslot"))-1]=1;
                }
                for(int k=0;k<22;k++)
                {
                	result += ""+a[k]; 
                } 
                
            }
            else{
                for(int k=0;k<22;k++)
                {
                	result += ""+a[k];
                }
            }
            
            String sql2="select * from salontime";
            SqlRowSet queryForRowSet2 = jdbc.queryForRowSet("select * from salontime");
        
                String[] b=new String[23];
                int i=0;
                while(queryForRowSet2.next()){
                    b[i]=queryForRowSet2.getString("timeslot");
                    i++;
                }
                for(int k=0;k<22;k++)
                {
                	result+= ""+b[k];
                }
       }
       catch(Exception e)
       {
          System.out.println("catch executed  "+e);
        }
		return result;

	}
	
	public String getBookingSlot(int timeslotint) {
		
		String timeslot = "";
		SqlRowSet queryForRowSet = jdbc.queryForRowSet("select * from salontime where timeslotint=?",timeslotint );
		while (queryForRowSet.next()) {
			
		timeslot= queryForRowSet.getString("timeslot");
			
		}
		//System.out.println(timeslot);
		return timeslot;

	}
	
	
}
