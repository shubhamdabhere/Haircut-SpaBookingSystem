package com.cts.project.HaircutSpaBookingSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(value="com.cts.project.HaircutSpaBookingSystem.*")
public class HaircutSpaBookingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HaircutSpaBookingSystemApplication.class, args);
	}
}