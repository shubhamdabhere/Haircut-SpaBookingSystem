package com.cts.project.HaircutSpaBookingSystem.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Service;

import com.cts.project.HaircutSpaBookingSystem.dao.User;


@Service
public class UserService {
	
	@Autowired
	private User user;
	
	@Autowired
	JdbcTemplate jdbc;
	
	public boolean isValidUser(String email, String password) {
		
		String sql = "select count(*) from user where email= '" + email + "' AND password= '" + password + "'";
		
		int count = jdbc.queryForObject(sql , Integer.class);
		return count == 1;

		
	}
	// this code is for add user to register 
	public void addUser(User user) {
		String sql = "insert into user values(?,?,?,?)";
		try {
			jdbc.update(sql, user.getUsername(), user.getEmail(), user.getPassword(), user.getMobile());
			//jdbc.update(sql, "apoorva", "abc@gmail.com", "123", "7772986606");
			
		} catch (Exception e) {
			System.out.println(e);
		}

	}
	
	public String getUsername(String email) {
		String sql = "insert into user values(?,?,?,?)";
		try {
			SqlRowSet queryForRowSet = jdbc.queryForRowSet("select username from user where email=?", email);
			//System.out.println(queryForRowSet.getString("username"));
			if(queryForRowSet.next()) {
				//System.out.println(queryForRowSet.getString("username"));
				return (String)queryForRowSet.getString("username");
			}else {
				return "";
			}
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
	     return "";
	}
	
	public boolean checkIfEmailExists(String email) {
		
		String sql = "select count(*) from user where email= '" + email + "'";
		
		int count = jdbc.queryForObject(sql , Integer.class);
		return count == 1;
		
	}

}
