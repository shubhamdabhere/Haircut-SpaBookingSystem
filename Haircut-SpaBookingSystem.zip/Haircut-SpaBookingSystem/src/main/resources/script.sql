-- Host: localhost    Database: salon_data

--
-- ------------------------------------------------------
-- create database
CREATE database salon_data;

--use database
use salon_data;

--Table structure for bookings table  
DROP TABLE IF EXISTS `bookings`;

	create table `bookings`(
        `bookingid` VARCHAR(300) NOT NULL UNIQUES,
        `email` VARCHAR(100) NOT NULL,
        `service` VARCHAR(100),
        `date` VARCHAR(100),
        `timeslot` int ,
        `booktime` VARCHAR(100),
        PRIMARY KEY ( bookingid )
        )ENGINE=InnoDB DEFAULT CHARSET=utf8;
        
--Table structure for user table        
DROP TABLE IF EXISTS `user`;

     create table `user`(
        `username` VARCHAR(100) NOT NULL,
        `email` VARCHAR(100) NOT NULL UNIQUE,
        `password` VARCHAR(100) ,
        `mobile` VARCHAR(100) ,
        PRIMARY KEY ( email )
        )ENGINE=InnoDB DEFAULT CHARSET=utf8;
    
--Table structure for salontime table
	DROP TABLE IF EXISTS `salontime`;	
	
	 create table `salontime`(
    `timeslot` VARCHAR(50),
    `timeslotint` int 
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;
    
 --  inserte values of the table  
 insert into salontime values ("10:00 am - 10:30am", 1);
 insert into salontime values ("10:30 am - 11:00am", 2);
 insert into salontime values ("11:00 am - 11:30am", 3); 			
 insert into salontime values ("10:00 am - 10:30am", 1);
 insert into salontime values ("10:30 am - 11:00am", 2);
 insert into salontime values ("11:00 am - 11:30am", 3);
 insert into salontime values ("11:30 am - 12:00pm", 4);
 insert into salontime values ("12:00 pm - 12:30pm", 5);
 insert into salontime values ("12:30 pm - 01:00pm", 6);
 insert into salontime values ("01:00 pm - 01:30pm", 7);
 insert into salontime values ("01:30 pm - 02:00pm", 8);
 insert into salontime values ("02:00 pm - 02:30pm", 9);
 insert into salontime values ("02:30 pm - 03:00pm", 10);
 insert into salontime values ("03:00 pm - 03:30pm", 11);
 insert into salontime values ("03:30 pm - 04:00pm", 12);
 insert into salontime values ("04:00 pm - 04:30pm", 13);
 insert into salontime values ("04:30 pm - 05:00pm", 14);
 insert into salontime values ("05:00 pm - 05:30pm", 15);
 insert into salontime values ("05:30 pm - 06:00pm", 16);
 insert into salontime values ("06:00 pm - 06:30pm", 17);
 insert into salontime values ("06:30 pm - 07:00pm", 18);
 insert into salontime values ("07:00 pm - 07:30pm", 19);
 insert into salontime values ("07:30 pm - 08:00pm", 20);
 insert into salontime values ("08:00 pm - 08:30pm", 21);
 insert into salontime values ("08:30 pm - 09:00pm", 22);	
 
 